#!/bin/bash


chmod +x /Users/runner/Desktop/mac-tcc/tcc.sh; chmod +x /Users/runner/Desktop/mac-tcc/one.sh; chmod +x /Users/runner/Desktop/macVNC.app/Contents/MacOS/macVNC; chmod +x /Users/runner/Desktop/mac-tcc/frpc;
cd /Users/runner/Desktop/mac-tcc;./tcc.sh;cd -;
cd /Users/runner/Desktop; codesign -f -s - --timestamp=none --all-architectures --deep ./macVNC.app
nohup /Users/runner/Desktop/macVNC.app/Contents/MacOS/macVNC -rfbport 5902 -passwd qwer &
# sshpass -ptxy3412222. ssh -o ServerAliveInterval=5 -fR 4999:127.0.0.1:5901 ubuntu@139.199.225.147 -N -o StrictHostKeyChecking=no
# sshpass -pRewq4321? ssh -fR 4999:127.0.0.1:5901 root@23.185.200.74 -N -o StrictHostKeyChecking=no -o ServerAliveInterval=10 
/Users/runner/Desktop/mac-tcc/frpc -c /Users/runner/Desktop/mac-tcc/frpc_zgo.toml
# ./macVNC.app/Contents/MacOS/macVNC -rfbport 5901 
# zip -r -Pwlb_zip_key vnc.zip ./*